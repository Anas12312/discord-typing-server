module.exports = {
    email: "anashesham200152@gmail.com", // your account's email
    password: "0102736245", // your account's password
    telegram_chat_id: "945827738", // (I will give it to you)
    telegram_bot_id: "7195798648:AAEcI8hmUELb3XTpMWblqFMljKcSeucjYbY", // (I will give it to you)
    token: "MTI1MDA3NzcwNjcwNDY1NDQ3Nw.GnFrPd.2lXA2nTXILPkdI7CuhPeUJQGOl_CjWaLLZIZas"
}