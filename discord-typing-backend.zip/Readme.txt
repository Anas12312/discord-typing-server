To run the script:

1- Extract the zip file
2- Navigate to the extracted file directory 
3- Open Terminal (CMD)
4- Type npm i  (Installing Dependancies)
5- Type node test.js
6- wait 15 minutes and thats it :)